from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
    path("regisztracio",views.regisztracio,name="regisztracio"),
    path("bejelentkezes",views.bejelentkezes,name="bejelentkezes"),
    path("",views.fooldal,name="fooldal"),
    path("kijelentkezes",auth_views.LogoutView.as_view(), name="kijelentkezes"),
    path("fooldal", views.fooldal, name="fooldal"),
    path("ujrecept", views.ujrecept, name="ujrecept"),
    path('ujsor',views.ujsor,name='ujsor'),
    path('tobbrecept',views.tobbrecept,name='tobbrecept'),
    path('recept/<int:recept_id>', views.recept, name='recept'),
    path('sajattobb',views.sajattobb, name='sajattobb'),
    path('sajat',views.sajat, name='sajat'),
    path('kajatorles/<int:kaja_id>/<int:keszito_id>', views.kajatorles, name='kajatorles')
]
