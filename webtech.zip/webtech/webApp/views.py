from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth import login, authenticate
from .forms import bejelentkezesForm, regisztracioForm, hozzavalokForm, kajaForm
from .models import hozzavalok
from django.core.paginator import Paginator
from django.http import JsonResponse
from .models import kaja
import os
from django.shortcuts import get_object_or_404,get_list_or_404
from django.conf import settings

# Create your views here.
def fooldal(request):
    if request.method == 'POST':
        return redirect('fooldal')
    return render(request, 'Fooldal.html')
def regisztracio(request):
    if request.method == 'POST':
        form = regisztracioForm(request.POST)
        if form.is_valid():
            user = form.save()
            return redirect('bejelentkezes')
    else:
        form = regisztracioForm()
    return render(request, 'Regisztracio.html', {'form': form})
def bejelentkezes(request):
    if request.method == 'POST':
        form = bejelentkezesForm(data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('fooldal')
            else:
                messages.error(request, 'Helytelen felhasználónév/jelszó!')
    else:
        form = bejelentkezesForm()
    return render(request, 'Bejelentkezes.html', {'form': form})
def ujrecept(request):
    if request.method=='POST':
        form=kajaForm(request.POST,request.FILES)
        felhasznalo=request.user
        if form.is_valid():
            kaja=form.save(commit=False)
            kaja.keszito_id=felhasznalo.id
            kaja.kaja_id=felhasznalo.receptekSzama
            kaja.kep.name="feltoltott_"+kaja.kep.name
            kaja.save()
            felhasznalo.receptekSzama+=1
            felhasznalo.save()
            return HttpResponse("")
    context={'form1':hozzavalokForm, 'hozzavalok':hozzavalok.objects.all(),'form2':kajaForm}
    return render(request,'Ujrecept.html',context)
def ujsor(request):
    if request.method == 'POST':
        form=hozzavalokForm(request.POST)
        felhasznalo=request.user
        if form.is_valid():
            hozzavalok=form.save(commit=False)
            hozzavalok.kaja_id=felhasznalo.receptekSzama
            hozzavalok.keszito_id=felhasznalo.id
            hozzavalok.save()
            return HttpResponse("")
    else:
        return render(request, 'hozzavaloElem.html',{'form1':hozzavalokForm})
def tobbrecept(request):
    oldal=request.GET.get('oldal',1)
    receptek=kaja.objects.all()
    paginator=Paginator(receptek,10)
    try:
        receptoldal=paginator.page(oldal)
    except:
        receptoldal=paginator.page(paginator.num_pages)
    data=[]
    for recept in receptoldal:
        data.append({
            'nev':recept.megnevezes,
            'leiras':recept.leiras(),
            'kep':recept.kep.url,
            'url':recept.getUrl()
        })


    return JsonResponse({'receptek':data,'has_next':receptoldal.has_next()})
def recept(request, recept_id):
    recept=get_object_or_404(kaja, id=recept_id)
    hozzavalolista=get_list_or_404(hozzavalok, kaja_id=recept.kaja_id, keszito_id=recept.keszito_id)
    felhasznalo=request.user
    return render(request, 'recept.html',{'recept':recept, 'hozzavalolista':hozzavalolista})
def sajattobb(request):
    oldal=request.GET.get('oldal',1)
    felhasznalo=request.user
    receptek=get_list_or_404(kaja, keszito_id=felhasznalo.id)
    paginator=Paginator(receptek,10)
    try:
        receptoldal=paginator.page(oldal)
    except:
        receptoldal=paginator.page(paginator.num_pages)
    data=[]
    for recept in receptoldal:
        data.append({
            'nev':recept.megnevezes,
            'leiras':recept.leiras(),
            'kep':recept.kep.url,
            'url':recept.getUrl()
        })
    return JsonResponse({'receptek':data,'has_next':receptoldal.has_next()})
def sajat(request):
    return render(request, 'sajat.html')
def kajatorles(request,kaja_id,keszito_id):
    recept=get_object_or_404(kaja, kaja_id=kaja_id)
    hozzavalolista=get_list_or_404(hozzavalok, kaja_id=kaja_id, keszito_id=keszito_id)
    ut=recept.kep.url
    recept.delete()
    for hozzavalo in hozzavalolista:
        hozzavalo.delete()
    eleres=os.path.abspath(os.path.dirname(settings.BASE_DIR))+"\\web jo"+ut.replace("/","\\")
    print(eleres)
    if os.path.exists(eleres):
        os.remove(eleres)
    return redirect('fooldal')