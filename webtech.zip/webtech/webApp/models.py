from django.db import models
from django.contrib.auth.models import AbstractUser
from django.urls import reverse
# Create your models here.
class felhasznalo(AbstractUser):
    receptekSzama=models.PositiveIntegerField(default=0)

class hozzavalok(models.Model):
    keszito_id=models.IntegerField()
    kaja_id=models.IntegerField()
    mennyiseg=models.FloatField()
    mertekegyseg=models.CharField(max_length=100)
    nev=models.CharField(max_length=100)


class kaja(models.Model):
    keszito_id=models.IntegerField()
    kaja_id=models.IntegerField()
    megnevezes=models.CharField(max_length=100)
    kep=models.ImageField(upload_to="static/")
    elkeszites=models.TextField()
    def leiras(self):
        if len(self.elkeszites)>100:
            return self.elkeszites[:100]+"-"
        else:
            return self.elkeszites
    def getUrl(self):
        return reverse('recept',args=[str(self.id)])
    