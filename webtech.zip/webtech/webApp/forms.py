from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.forms import AuthenticationForm
from .models import kaja, hozzavalok,felhasznalo

class regisztracioForm(UserCreationForm):
    email=forms.EmailField(required=True)
    class Meta:
        model=felhasznalo
        fields = ['username','email','password1','password2']

class bejelentkezesForm(AuthenticationForm):
    username=forms.CharField(label='username')
    password=forms.CharField(label='password',widget=forms.PasswordInput)
    
class hozzavalokForm(forms.ModelForm):
    class Meta:
        model = hozzavalok
        fields = ['mennyiseg', 'mertekegyseg','nev']

class kajaForm(forms.ModelForm):
    class Meta:
        model = kaja
        fields = ['megnevezes', 'kep', 'elkeszites']